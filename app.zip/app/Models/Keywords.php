<?php
/**
 * Created by PhpStorm.
 * User: cahaya
 * Date: 10/5/17
 * Time: 4:12 PM
 */

namespace App\Models;


use Illuminate\Database\Eloquent\Model;

class keywords extends Model
{
    protected $table = 'tbl_keywords';
    protected $primaryKey = 'id';
}