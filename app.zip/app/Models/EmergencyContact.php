<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class EmergencyContact extends Model 
{
    
     protected $table = 'tbl_emergency_contacts';

    protected $primaryKey = 'id';

}
